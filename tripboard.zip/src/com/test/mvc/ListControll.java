package com.test.mvc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.test.sub.IBoardDAO;

public class ListControll implements Controller
{

	/*// �������̽� �ڷ����� ���ϴ� �Ӽ� ����
	private IBoardDAO dao;
	
	// setter �޼ҵ� ����
	public void setDao(IBoardDAO dao)
	{
		this.dao = dao;
	}*/
	
	@Override
	public ModelAndView handleRequest(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception
	{
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("WEB-INF/views/List.jsp");
		
		return mav;
	}

}
